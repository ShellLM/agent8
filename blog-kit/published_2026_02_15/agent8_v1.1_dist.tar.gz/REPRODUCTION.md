bash agent8.sh
